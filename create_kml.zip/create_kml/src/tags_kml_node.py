#! /usr/bin/env python

import rospy
import message_filters
from sensor_msgs.msg import Image, NavSatFix 
from std_msgs.msg import String, Int32
from create_kml.msg import kml_msg
from cv_bridge import CvBridge
import cv2
import time

count = 1
bridge = CvBridge()

def callback(msg):
	global count
	
	cv_image = bridge.imgmsg_to_cv2(msg.img, desired_encoding="passthrough")
	name = str(msg.name)+str(count)
	cv2.imwrite(name+'.jpg',cv_image)
	
	s = '<?xml version="1.0" encoding="UTF-8"?>'
	s = s + '\n<kml xmlns="http://www.opengis.net/kml/2.2">'
	s = s + '\n<Placemark>\n<name>'+ str(msg.name)+'</name>'
	s = s + '<Point>\n<coordinates>'+str(msg.gps.longitude)+','+str(msg.gps.latitude)+'</coordinates>'
	s = s + '\n</Point>'
	s = s + '<description><icon>'+name+'.jpg”</icon></description>'
	s = s + '</placemark></kml>'
			
	file = open(name +'.kml','w') 
	file.write(s)
	file.close()
	count +=1		
	time.sleep(10)# wait 10 seconds	(you can change this one based on your need)


rospy.init_node('tags_kml_node')



kml_sub = rospy.Subscriber('/kml', kml_msg, callback, queue_size=1)# set the queue size to one to eliminate some detections, try to send the messages with the same queue size


rospy.spin()
